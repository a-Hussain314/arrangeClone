import React, { Component } from 'react';
import {
    View,
    Text,

} from 'react-native';
import { Tab, Tabs, TabHeading } from 'native-base';
import { colors, fonts } from '../../../../Theme';
import { globalImagePath } from '../../../../constants/globalImagePath';
import { styles } from './styles';
import Tab1 from '../SalonDetails/SalonOverView/SalonOverView';
import Tab2 from '../SalonDetails/SalonServices/SalonServices';
import Tab3 from '../SalonDetails/SalonGallery/SalonGallery';
import Tab4 from '../SalonDetails/SalonReview/SalonReview';
import I18n from '../../../../I18n';
import ParallaxScrollView from 'react-native-parallax-scrollview';
import { getService } from '../../../../services/getServices';
import { postService } from '../../../../services/postServices';
import Loader from '../../../../components/Loader';
import { useIsFocused } from "@react-navigation/native";
import {
    showToast,
    showDangerToast,
    showDangerToastLong,
} from '../../../../components/ToastMessage';
export default function SearchDetails({ navigation, route, props }) {
    const isFocused = useIsFocused();
    const [currentTab, setCurrentTab] = React.useState(0);
    const [loading, setLoading] = React.useState(false);
    const [salonDetails, setSalonDetails] = React.useState(false);
    const [salonId, setSalonId] = React.useState('');
    const [addFav, setAddFav] = React.useState(true);
    React.useEffect(() => {
        let salon_id = route.params && route.params.salonId;

        setSalonId(salon_id);
        getSalonDetails(salon_id)
    }, [props, isFocused]);

    function getSalonDetails(salon_id) {
        setLoading(true);
        //***** api calling */
        getService(`salonlist/salonById/${salon_id}`)
            .then(res => {
                setLoading(false);

                if (res.data.status === 1) {
                    setLoading(false);
                    let data = res.data.response;
                    setSalonDetails(data)

                } else {
                    setLoading(false);
                    setTimeout(function () {
                        showDangerToast(res.data.message);
                    }, 100);
                }
            })
            .catch(error => {
                setLoading(false);
                setTimeout(function () {
                    alert(error);
                }, 100);
            });
    };

    function addFavSaloon() {
        setLoading(true);

        const data = {
            salon_id: salonDetails._id,
            isFav: 1
        }
        console.log("addFavSaloon", data);
        //***** api calling */
        postService('salonlist/adddel-fav', data)
            .then(res => {
                setLoading(false);

                if (res.data.status === 1) {
                    setLoading(false);
                    showToast(res.data.message);

                } else {
                    setLoading(false);
                    setTimeout(function () {
                        showDangerToast(res.data.message);
                    }, 100);
                }
            })
            .catch(error => {
                setLoading(false);
                setTimeout(function () {
                    alert(error);
                }, 100);
            });
    };

    function removeFavSaloon() {
        setLoading(true);

        const data = {
            salon_id: salonDetails._id,
            isFav: 0
        }
        // console.log("removeFavSaloon", data);
        //***** api calling */
        postService('salonlist/adddel-fav', data)
            .then(res => {
                setLoading(false);

                if (res.data.status === 1) {
                    setLoading(false);
                    showToast(res.data.message);

                } else {
                    setLoading(false);
                    setTimeout(function () {
                        showDangerToast(res.data.message);
                    }, 100);
                }
            })
            .catch(error => {
                setLoading(false);
                setTimeout(function () {
                    alert(error);
                }, 100);
            });
    };

    const setToggle = () => {
        console.log("addFav", addFav);
        if (addFav) {
            addFavSaloon();
        } else {
            removeFavSaloon();
        }
        setAddFav(!addFav)
    }
    return (
        <View style={{ flex: 1, }}>
            <Loader loading={loading} />
            <ParallaxScrollView
                windowHeight={667 * 0.4}
                webUrl={salonDetails ? true : false}
                backgroundSource={"https://arrangeapp.devtechnosys.tech:17338/public/uploads/salonbanners/" + salonDetails.banner_salon}
                navBarTitle='John Oliver'
                userName='John Oliver'
                userTitle='Comedian'
                navBarTitleColor={'#000'}
                navBarColor={'#fff'}
                navigator={navigation}
                toggle={addFav}
                addFav={() => setToggle()}
            >
                <View style={{ flex: 1, backgroundColor: '#fff' }}>
                    <Tabs position={"bottom"} tabBarUnderlineStyle={{ backgroundColor: colors.themeColor }} onChangeTab={({ i }) => setCurrentTab(i)}>
                        {salonDetails ?
                            <Tab heading={<TabHeading style={{ backgroundColor: '#fff', paddingBottom: 5 }}>
                                <View style={{ alignItems: 'center' }}>
                                    <Text style={currentTab == 0 ? styles.activeTab : styles.inActiveTab}>{I18n.t('lbl_overView')}</Text>
                                </View>
                            </TabHeading>}
                                tabStyle={{ backgroundColor: '#fff' }}
                                activeTabStyle={{ backgroundColor: '#fff', borderTopWidth: 0.5 }}>
                                <Tab1 navigation={navigation} salonDetails={salonDetails} />
                            </Tab> : null}
                        {salonId ?
                            <Tab heading={<TabHeading style={{ backgroundColor: '#fff', paddingBottom: 5 }}>
                                <View style={{ alignItems: 'center' }}>
                                    <Text style={currentTab == 1 ? styles.activeTab : styles.inActiveTab}>{I18n.t('lbl_srvice')}</Text>
                                </View>
                            </TabHeading>}
                                tabStyle={{ backgroundColor: '#fff' }}
                                activeTabStyle={{ backgroundColor: '#fff' }}>
                                <Tab2 salonId={salonId} navigation={navigation} />

                            </Tab>
                            : null}
                        {salonId ?
                            <Tab heading={<TabHeading style={{ backgroundColor: '#fff', paddingBottom: 5 }}>
                                <View style={{ alignItems: 'center' }}>
                                    <Text style={currentTab == 2 ? styles.activeTab : styles.inActiveTab}>{I18n.t('lbl_gallery')}</Text>
                                </View>
                            </TabHeading>}
                                tabStyle={{ backgroundColor: '#fff' }}
                                activeTabStyle={{ backgroundColor: '#fff', borderTopWidth: 0.5 }}>
                                <Tab3 salonId={salonId} />
                            </Tab> : null}
                        <Tab heading={<TabHeading style={{ backgroundColor: '#fff', paddingBottom: 5 }}>
                            <View style={{ alignItems: 'center' }}>
                                <Text style={currentTab == 3 ? styles.activeTab : styles.inActiveTab}>{I18n.t('lbl_review')}</Text>
                            </View>
                        </TabHeading>}
                            tabStyle={{ backgroundColor: '#fff' }}
                            activeTabStyle={{ backgroundColor: '#fff' }}>
                            <Tab4 />
                        </Tab>

                    </Tabs>
                </View>

            </ParallaxScrollView>


        </View>
    );
}
