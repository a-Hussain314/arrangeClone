import React, { Component } from 'react';
import { View, Text, FlatList, ScrollView, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { height, width } from '../../../../../constants/screenSize';
import { fonts, colors } from '../../../../../Theme';
// import { styles } from './styles';
import { globalImagePath } from '../../../../../constants/globalImagePath';
import { postService } from '../../../../../services/postServices';
import font from '../../../../../Theme/font';
import Loader from '../../../../../components/Loader';
export default function SalonServices({ navigation, salonId }) {
    const [loading, setLoading] = React.useState(false);
    const [services, setService] = React.useState([]);
    React.useEffect(() => {
        getServiceDetails(salonId)
    }, []);

    function getServiceDetails(salonId) {
        setLoading(true);
        const data = {
            salon_id: salonId
        }
        //***** api calling */
        postService('salonlist/salonservices-byid', data)
            .then(res => {
                setLoading(false);

                if (res.data.status === 1) {
                    setLoading(false);
                    let data = res.data.response.records;
                    console.log("serviceDetails", data);
                    //  setSalonDetails(data)
                    setService(data)

                } else {
                    setLoading(false);
                    setTimeout(function () {
                        showDangerToast(res.data.message);
                    }, 100);
                }
            })
            .catch(error => {
                setLoading(false);
                setTimeout(function () {
                    alert(error);
                }, 100);
            });
    };

    // Render recommand salon
    const recommandSalon = (item, index) => {
        return (
            <TouchableOpacity style={styles.renderOuterView} onPress={() => { }}>
                <View style={{
                    backgroundColor: '#fff',
                    borderRadius: 10,
                    flexDirection: 'row',
                    flex: 1,
                    paddingVertical: 12,
                    paddingHorizontal: 8
                }}>
                    <View style={{ justifyContent: 'center' }}>
                        <Image source={{ uri: "https://arrangeapp.devtechnosys.tech:17338/public/uploads/salon-service/" + item.image }} style={styles.image} resizeMode={'cover'} />
                    </View>
                    <View style={{ flex: 1, marginLeft: 20, }}>

                        <View style={{ flex: 1 }}>
                            <Text style={{ fontWeight: 'bold', color: '#000', fontSize: 12, }}>{item.salon_service}</Text>
                            <Text style={{ marginTop: 5, color: colors.darkShade, fontSize: 14, }}>{'USD 20.00'}</Text>
                        </View>
                        <TouchableOpacity style={{ borderRadius: 5, alignSelf: 'flex-end', paddingHorizontal: 8, paddingVertical: 7, justifyContent: 'center', alignItems: 'center', width: 80, flexDirection: 'row', borderWidth: 0.8, borderColor: colors.themeColor }}>
                            <View style={{ justifyContent: "center" }}>
                                <Image source={globalImagePath.addIcon} style={styles.addimage} resizeMode={'cover'} />
                            </View>
                            <View style={{ marginLeft: 5 }}>
                                <Text style={{ color: colors.darkShade, fontSize: 14, }}>{'ADD'}</Text>
                            </View>
                        </TouchableOpacity>

                    </View>
                </View>
            </TouchableOpacity>
        );
    };


    return (
        <View style={{

            borderWidth: 1,
            flex: 1,
        }}>
            <Loader loading={loading} />
            <View style={{ marginHorizontal: width * (20 / 375), flex: 1, marginTop: 20, borderColor: 'red', }}>
                <FlatList
                    showsVerticalScrollIndicator={false}
                    data={services}
                    renderItem={({ item, index }) =>
                        recommandSalon(item, index)
                    }
                    keyExtractor={(item, index) => String(index)}
                />

            </View>
            <View style={{ justifyContent: 'center', paddingHorizontal: 15, top: 300, width: width * (334 / 375), alignSelf: 'center', position: 'absolute', marginHorizontal: 20, height: 80, borderRadius: 10, backgroundColor: 'rgba(0,0,0,0.1)' }} >
                <View style={{ flexDirection: 'row', }}>
                    <View style={{ flex: 1 }}>
                        <View>
                            <Text style={{ color: '#fff', fontSize: 10, fontFamily: fonts.type.proximanova_semibold }}>{'2 SERVICES ADD'}</Text>
                        </View>
                        <Text style={{ color: '#fff', fontSize: 18 }}>{'USD 142.00'}</Text>
                    </View>
                    <TouchableOpacity onPress={() => { navigation.navigate('SelectDateAndTime') }} style={{ height: width * (35 / 375), backgroundColor: '#fff', borderRadius: 5, alignSelf: 'flex-end', paddingHorizontal: 8, paddingVertical: 7, justifyContent: 'center', alignItems: 'center', width: 100, flexDirection: 'row', borderWidth: 0.8, borderColor: colors.themeColor }}>
                        <View style={{ marginLeft: 5 }}>
                            <Text style={{ color: colors.darkShade, fontSize: 14, }}>{'Book Now'}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>

        </View>
    );

}

const styles = StyleSheet.create({
    renderOuterView: {
        flexDirection: 'row',
        marginTop: width * (10 / 375),

        paddingBottom: 2,
        paddingRight: 2,
        paddingTop: 2,
        paddingLeft: 2,
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
        borderTopRightRadius: 15,
        borderTopLeftRadius: 15,
        backgroundColor: 'transparent',
        shadowColor: '#000',
        //  marginRight: 10,
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 2,

    },
    image: {
        // borderWidth: 5,
        height: width * (88 / 375),
        width: width * (88 / 375),
        borderRadius: 10,
    },
    addimage: {
        // borderWidth: 5,
        height: width * (11 / 375),
        width: width * (11 / 375),
        borderRadius: 10,
    },
})
