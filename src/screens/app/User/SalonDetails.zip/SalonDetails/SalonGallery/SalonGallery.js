import React, { Component } from 'react';
import { View, Text, FlatList, ScrollView, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { height, width } from '../../../../../constants/screenSize';
import { fonts, colors } from '../../../../../Theme';
// import { styles } from './styles';
import { globalImagePath } from '../../../../../constants/globalImagePath'
import font from '../../../../../Theme/font';
import Loader from '../../../../../components/Loader';
import { postService } from '../../../../../services/postServices';
export default function SalonGallery({ navigation, salonId }) {

    const [loading, setLoading] = React.useState(false);

    const [recommendSalon, setRecommendSalon] = React.useState();
    React.useEffect(() => { getSalonGallery(salonId) }, []);

    function getSalonGallery(salonId) {
        setLoading(true);
        //***** api calling */

        const data = {
            salon_id: salonId
        }

        postService('salonlist/salongallery-byid', data)
            .then(res => {
                setLoading(false);

                if (res.data.status === 1) {
                    setLoading(false);
                    let data = res.data.response;
                    console.log("data =>", data);

                    setRecommendSalon(data.images)

                } else {
                    setLoading(false);
                    setTimeout(function () {
                        showDangerToast(res.data.message);
                    }, 100);
                }
            })
            .catch(error => {
                setLoading(false);
                setTimeout(function () {
                    alert(error);
                }, 100);
            });
    };

    // Render recommand salon
    const recommandSalon = (item, index) => {
        return (

            <View style={{ justifyContent: 'center', marginRight: 6, }}>
                <Image source={{ uri: "https://arrangeapp.devtechnosys.tech:17338/public/uploads/user/" + item.image_name }} style={styles.image} resizeMode={'cover'} />
            </View>

        );
    };

    return (
        <ScrollView style={{
            flex: 1,
            marginHorizontal: width * (20 / 375),
            backgroundColor: '#fff',
        }}>
            <Loader loading={loading} />
            <View style={{ flex: 1, marginTop: 20, borderColor: 'red', }}>
                <FlatList
                    numColumns={3}
                    showsVerticalScrollIndicator={false}
                    data={recommendSalon}
                    renderItem={({ item, index }) =>
                        recommandSalon(item, index)
                    }
                    keyExtractor={(item, index) => String(index)}
                />

            </View>

        </ScrollView>
    );

}

const styles = StyleSheet.create({
    renderOuterView: {
        flexDirection: 'row',
        marginTop: width * (10 / 375),

        paddingBottom: 2,
        paddingRight: 2,
        paddingTop: 2,
        paddingLeft: 2,
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
        borderTopRightRadius: 15,
        borderTopLeftRadius: 15,
        backgroundColor: 'transparent',
        shadowColor: '#000',
        //  marginRight: 10,
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 2,

    },
    image: {
        // borderWidth: 5,
        height: width * (107 / 375),
        width: width * (107 / 375),
        borderRadius: 10,
    },
    addimage: {
        // borderWidth: 5,
        height: width * (11 / 375),
        width: width * (11 / 375),
        borderRadius: 10,
    },
})
