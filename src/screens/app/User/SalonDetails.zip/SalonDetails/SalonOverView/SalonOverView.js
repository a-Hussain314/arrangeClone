import React, { Component } from 'react';
import { View, Text, FlatList, ScrollView } from 'react-native';
import { height, width } from '../../../../../constants/screenSize';
import { fonts, colors } from '../../../../../Theme';
//import { styles } from './styles';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import font from '../../../../../Theme/font';
import I18n from '../../../../../I18n';
import { globalImagePath } from '../../../../../constants/globalImagePath';
export default function SearchOverView({ navigation, salonDetails }) {
    const [salonWeek, setSalonWeek] = React.useState([
        { title: 'Monday', time: '10am-7:30pm' },
        { title: 'Tuesday', time: '10am-7:30pm' },
        { title: 'Wednesday', time: '10am-7:30pm' },
        { title: 'Thursday', time: '10am-7:30pm' },
        { title: 'Friday', time: '10am-7:30pm' },
        { title: 'Saturday', time: 'Closed' },
        { title: 'Sunday', time: 'Closed' },
    ]);
    const [overviewDetails, setSalonOverviewDetails] = React.useState('');
    const [region, setRegion] = React.useState({
        latitude: 37.78825,
        longitude: -122.4324,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
    })

    React.useEffect(() => {

        if (salonDetails) {
            setSalonOverviewDetails(salonDetails)
        }
    }, []);

    // Render salon time
    const recommandSalon = (item, index) => {
        return (
            <View style={{ flexDirection: 'row', marginTop: 20 }}>
                <View style={{ flex: 0.5, flexDirection: 'row', }}>
                    <View style={{ flex: 1 }}>
                        <Text style={{ color: colors.themeColor, fontFamily: font.type.NunitoSans_bold, fontSize: 14, }}>{item.title}</Text>
                    </View>
                    <Text>{':'}</Text>
                </View>
                <View style={{ right: -50, flex: 0.5, alignItems: 'flex-start' }}>
                    {item.time != 'Closed' ?
                        <Text style={{
                            color: colors.themeColor,
                            fontFamily: font.type.NunitoSans_Regular,
                            fontSize: 14,
                        }}>{item.time}</Text>
                        :
                        <Text style={{
                            color: 'red',
                            fontFamily: font.type.NunitoSans_Regular,
                            fontSize: 14,
                        }}>{item.time}</Text>
                    }
                </View>
            </View>
        );
    };

    const onRegionChange = (region) => {
        this.setState({ region });
    }
    return (
        <ScrollView style={{
            flex: 1,
            marginHorizontal: width * (20 / 375),
            backgroundColor: '#fff',

        }}>
            <View style={{
                flex: 1,

            }}>
                <View style={{ marginTop: 20 }}>
                    <Text style={{ fontFamily: font.type.NunitoSans_bold, fontSize: 16, }}>{I18n.t('lbl_address')}</Text>
                    <Text style={{
                        color: colors.themeColor,
                        // fontFamily: font.type.OpenSans_Regular,
                        fontSize: 12
                    }}>{overviewDetails.address}</Text>
                </View>
                <View style={{ marginTop: 20 }}>
                    <Text style={{ fontFamily: font.type.NunitoSans_bold, fontSize: 16 }}>{I18n.t('lbl_view_map')}</Text>
                </View>
                <View style={{ marginTop: 7, borderRadius: 10 }}>
                    <MapView
                        // provider={PROVIDER_GOOGLE}
                        style={{ height: 180, borderRadius: 10 }}
                        initialRegion={{
                            latitude: overviewDetails.lat ? overviewDetails.lat : 24.466667,
                            longitude: overviewDetails.lng ? overviewDetails.lng : 54.366669,
                            latitudeDelta: 0.0922,
                            longitudeDelta: 0.0421,
                        }}

                    >
                        <MapView.Marker
                            coordinate={{ latitude: overviewDetails.lat ? overviewDetails.lat : 24.466667, longitude: overviewDetails.lng ? overviewDetails.lng : 54.366669 }}
                            // title={'arrange'}
                            image={globalImagePath.location_marker}
                            description={"marker.description"}
                        ></MapView.Marker>
                    </MapView>
                </View>
                <View style={{ marginTop: 20 }}>
                    <Text style={{ fontFamily: font.type.NunitoSans_bold, fontSize: 16 }}>{I18n.t('lbl_working_hours')}</Text>
                    <View style={{ flexDirection: 'row', marginTop: 10 }}>
                        <Text style={{ color: 'lightgreen', fontFamily: font.type.NunitoSans_bold, fontSize: 14 }}>{I18n.t('lbl_open')}</Text>
                        <Text style={{ marginHorizontal: 10, top: -4, fontFamily: font.type.NunitoSans_bold, fontSize: 14 }}>{'.'}</Text>
                        <Text style={{ fontFamily: font.type.NunitoSans_bold, fontSize: 14 }}>{I18n.t('lbl_close_time')}</Text>
                    </View>
                </View>

                <View style={{ marginBottom: 20, flex: 1, paddingVertical: 10, paddingHorizontal: 10, borderColor: colors.themeColor, borderWidth: 0.5, borderRadius: 10, marginTop: 10 }}>
                    <FlatList
                        data={salonWeek}
                        renderItem={({ item, index }) =>
                            recommandSalon(item, index)
                        }
                        keyExtractor={(item, index) => String(index)}
                    />
                </View>
            </View>
        </ScrollView>
    );

}
