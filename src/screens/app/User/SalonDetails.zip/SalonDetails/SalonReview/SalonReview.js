import React, { Component } from 'react';
import { View, Text, FlatList, ScrollView, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { height, width } from '../../../../../constants/screenSize';
import { fonts, colors } from '../../../../../Theme';
// import { styles } from './styles';
import { globalImagePath } from '../../../../../constants/globalImagePath'
import font from '../../../../../Theme/font';
import { Rating, AirbnbRating } from 'react-native-ratings';
import I18n from '../../../../../I18n';
export default function SalonReview({ navigation }) {
    const [recommendSalon, setRecommendSalon] = React.useState([
        { title: 'Straight Gloss Therapy - Upto Neck', img: globalImagePath.bg, },
        { title: 'Spot Lights - Organic Eye - Lip Treatment', img: globalImagePath.bg, },
        { title: 'Threading - Upper Lip', img: globalImagePath.bg, },
        { title: 'CAFE AND RESTAURANTS', img: globalImagePath.bg, },
        { title: 'Bleach - Full Back- Front', img: globalImagePath.bg, },
        { title: 'Bleach - Full Back- Front ', img: globalImagePath.bg, },

    ]);
    React.useEffect(() => { }, []);

    // Render recommand salon
    const recommandSalon = (item, index) => {
        return (
            <TouchableOpacity style={styles.renderOuterView} onPress={() => { }}>
                <View style={{
                    backgroundColor: '#fff',
                    borderRadius: 10,
                    flexDirection: 'row',
                    flex: 1,
                    paddingVertical: 12,
                    paddingHorizontal: 8
                }}>

                    <Image source={item.img} style={styles.image} resizeMode={'cover'} />

                    <View style={{ flex: 1, marginLeft: 20, }}>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 1 }}>
                                <View style={{ flexDirection: 'row', }}>
                                    <View style={{ flex: 1 }}>
                                        <Text style={{ fontWeight: 'bold', color: '#000', fontSize: 12, }}>{item.title}</Text>
                                    </View>
                                    <View style={styles.ratingOuter}>
                                        <View style={styles.sterImg}>
                                            <Image source={globalImagePath.star} style={{}} />
                                        </View>
                                        <View style={{ justifyContent: 'center' }}>
                                            <Text style={styles.rateText}>{'4.5'}</Text>
                                        </View>
                                    </View>
                                </View>
                                <View style={{}}>
                                    <Text style={{ marginBottom: 5, color: colors.themeColor, fontSize: 12, }}>{'Spot Lights - Organic Eye'}</Text>
                                </View>
                            </View>

                        </View>

                        <View style={{ justifyContent: 'center', }}>
                            <Text style={{ color: 'rgb(110,118,130)', fontSize: 12, }}>{"Shawn is the best coach and is very supportive. He is a bit strict, but that is for our good only. "}</Text>
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        );
    };

    const ratingCompleted = (rating) => {
        console.log("Rating is: " + rating)
    }

    return (
        <ScrollView style={{
            flex: 1,
            marginHorizontal: width * (20 / 375),
            backgroundColor: '#fff',

        }}>
            <View style={{ marginTop: 50, alignItems: 'center' }}>
                <View>
                    <Text style={{ textAlign: 'center', fontSize: 14, color: colors.themeColor }}>{I18n.t('lbl_overall_rate')}</Text>
                    <View style={{ alignItems: 'center' }}>
                        <Text style={{ fontSize: 50, fontWeight: 'bold' }}>{'4.5'}</Text>
                    </View>

                    <AirbnbRating
                        count={5}
                        defaultRating={0}
                        size={30}
                        onFinishRating={ratingCompleted}
                    />

                    <Text style={{ marginTop: 10, textAlign: 'center', fontSize: 14, color: colors.themeColor }}>{I18n.t('lbl_baseon_review')}</Text>

                </View>
            </View>
            <View style={{ flex: 1, marginTop: 20, borderColor: 'red', }}>
                <FlatList
                    showsVerticalScrollIndicator={false}
                    data={recommendSalon}
                    renderItem={({ item, index }) =>
                        recommandSalon(item, index)
                    }
                    keyExtractor={(item, index) => String(index)}
                />

            </View>

        </ScrollView>
    );

}

const styles = StyleSheet.create({
    renderOuterView: {
        flexDirection: 'row',
        marginTop: width * (10 / 375),

        paddingBottom: 2,
        paddingRight: 2,
        paddingTop: 2,
        paddingLeft: 2,
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
        borderTopRightRadius: 15,
        borderTopLeftRadius: 15,
        backgroundColor: 'transparent',
        shadowColor: '#000',
        //  marginRight: 10,
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 2,

    },
    image: {
        // borderWidth: 5,
        height: width * (46 / 375),
        width: width * (46 / 375),
        borderRadius: 10,
    },
    addimage: {
        // borderWidth: 5,
        height: width * (11 / 375),
        width: width * (11 / 375),
        borderRadius: 10,
    },
    ratingOuter: {
        backgroundColor: 'rgb(11,199,117)',
        flexDirection: 'row',
        paddingVertical: width * (2 / 375),
        paddingHorizontal: width * (5 / 375),
        borderRadius: width * (5 / 375),
        height: width * (20 / 375)
    },
    sterImg: {
        justifyContent: 'center', alignSelf: 'center',

    },
    rateText: {
        color: colors.whiteColor,
        marginLeft: width * (2 / 375),
        fontSize: 10

    },
})
